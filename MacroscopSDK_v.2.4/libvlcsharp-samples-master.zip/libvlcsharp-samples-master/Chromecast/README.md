# Chromecast sample

### Prerequisite
- Your device/simulator must be connected to wifi and have internet
- A chromecast must be setup on your local wifi network

### Possible improvements
- Use a crossplatform filepicker to cast local files
- List local files in a crossplatform way
- List all discovered chromecasts