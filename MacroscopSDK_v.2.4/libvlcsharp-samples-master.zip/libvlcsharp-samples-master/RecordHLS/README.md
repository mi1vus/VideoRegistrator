# RecordHLS sample

### Possible improvements
- Add support for .NET Core mac/linux