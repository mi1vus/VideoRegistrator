﻿namespace MyHomeSecureWeb.Models
{
    public class HubConnectionStatus : SocketMessageBase
    {
        public bool Connected { get; set; }
    }
}
