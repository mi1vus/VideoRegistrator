﻿namespace MyHomeSecureWeb.Models
{
    public class HubLocation
    {
        public string HubId { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public float Radius { get; set; }
    }
}
