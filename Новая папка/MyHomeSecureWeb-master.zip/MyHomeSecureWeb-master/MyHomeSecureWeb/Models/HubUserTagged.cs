﻿namespace MyHomeSecureWeb.Models
{
    public class HubUserTagged : SocketMessageBase
    {
        public string UserName { get; set; }
    }
}
