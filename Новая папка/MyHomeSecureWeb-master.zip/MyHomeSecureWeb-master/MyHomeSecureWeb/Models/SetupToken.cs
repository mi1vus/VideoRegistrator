﻿namespace MyHomeSecureWeb.Models
{
    public class SetupTokenResponse
    {
        public string UserName { get; set; }
        public string Token { get; set; }
    }
}
