﻿using System;

namespace MyHomeSecureWeb.WebSockets
{
    public interface ISocketTarget : IDisposable
    {
    }
}
