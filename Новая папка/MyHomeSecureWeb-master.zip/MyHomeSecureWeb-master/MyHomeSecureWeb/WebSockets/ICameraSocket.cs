﻿namespace MyHomeSecureWeb.WebSockets
{
    public interface ICameraSocket
    {
        void initialise(string homeHubId, string node);
    }
}
