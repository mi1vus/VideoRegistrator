﻿namespace MyHomeSecureWeb.WebSockets
{
    public interface IUserAppSocket : ISocketSender
    {
        
    }
}
